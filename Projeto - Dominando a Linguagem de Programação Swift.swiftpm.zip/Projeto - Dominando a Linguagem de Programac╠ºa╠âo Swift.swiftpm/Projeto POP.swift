import UIKit

protocol Task {
    var title: String { get }
    var status: TaskStatus { get set }
}

enum TaskStatus {
    case toDo
    case inProgress
    case completed
}

struct SimpleTask: Task {
    let title: String
    var status: TaskStatus
}

func listTasks(_ tasks: [Task]) {
    for (index, task) in tasks.enumerated() {
        print("\(index + 1). \(task.title) - \(task.status)")
    }
}

func markTaskAsCompleted(_ taskIndex: Int, in tasks: inout [Task]) {
    if taskIndex >= 0 && taskIndex < tasks.count {
        tasks[taskIndex].status = .completed
    }
}

class TaskListViewController: UIViewController {
    var tasks: [Task] = [
        SimpleTask(title: "Fazer compras", status: .toDo),
        SimpleTask(title: "Estudar Swift", status: .inProgress)
    ]
    
    override func viewDidLoad() {
        super.viewDidLoad()

        listTasks(tasks)
        markTaskAsCompleted(0, in: &tasks)
        listTasks(tasks)
    }
}

func main() {

    let app = UIApplicationMain(CommandLine.argc, CommandLine.unsafeArgv, nil, NSStringFromClass(TaskListViewController.self))

    UIApplicationMain(CommandLine.argc, CommandLine.unsafeArgv, nil, NSStringFromClass(TaskListViewController.self))
}

main()

