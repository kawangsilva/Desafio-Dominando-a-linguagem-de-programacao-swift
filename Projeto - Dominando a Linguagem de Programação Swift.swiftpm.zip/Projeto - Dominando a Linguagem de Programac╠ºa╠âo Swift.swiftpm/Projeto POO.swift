import UIKit

enum TaskStatus {
    case toDo
    case inProgress
    case completed
}

struct Task {
    let title: String
    var status: TaskStatus

    init(title: String, status: TaskStatus) {
        self.title = title
        self.status = status
    }
}

class ToDoList {
    var tasks: [Task] = []
    
    func addTask(title: String) {
        let newTask = Task(title: title, status: .toDo)
        tasks.append(newTask)
    }
    
    func listTasks() {
        for (index, task) in tasks.enumerated() {
            print("\(index + 1). \(task.title) - \(task.status)")
        }
    }

    func markTaskAsCompleted(index: Int) {
        if index >= 0 && index < tasks.count {
            tasks[index].status = .completed
        }
    }
}

class TaskListViewController: UIViewController {
    let toDoList = ToDoList()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        toDoList.addTask(title: "Fazer compras")
        toDoList.addTask(title: "Estudar Swift")

        let label = UILabel(frame: CGRect(x: 20, y: 100, width: view.frame.width - 40, height: 200))
        label.numberOfLines = 0
        label.text = "Lista de tarefas:\n" + toDoList.tasks.map { "\($0.title) - \($0.status)" }.joined(separator: "\n")
        view.addSubview(label)
    }
}

func main() {

    let appOne = UIApplicationMain(CommandLine.argc, CommandLine.unsafeArgv, nil, NSStringFromClass(TaskListViewController.self))

    UIApplicationMain(CommandLine.argc, CommandLine.unsafeArgv, nil, NSStringFromClass(TaskListViewController.self))
}

main()
